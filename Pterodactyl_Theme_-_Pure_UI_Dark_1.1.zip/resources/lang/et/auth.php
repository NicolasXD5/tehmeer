<?php

return [
    '2fa_failed' => '2-astmelise autentimise token oli vale',
    '2fa_required' => '2-astmeline autentimine',
    'authentication_required' => 'Jätkamiseks on sisselogimine vajalik',
    'auth_error' => 'Logimisel on tekkinud viga ',
    'confirmpassword' => 'Kinnita salasõna',
    'email_sent' => 'Salasõna taastamiseks on Teie emailile saadetud juhised',
    'errorencountered' => 'Selle käsu täitmisel juhtus viga',
    'failed' => 'Kasutajanimi või salasõna on vale',
    'forgot_password' => 'Unustasid parooli?',
    'not_authorized' => 'Teil ei ole luba selle käsu sooritamiseks',
    'password_requirements' => 'Salasõna peab sisalda vähemalt ühte väikest tähte, suurt tähte, numbreid ja salasõna pikkus peab olema vähemalt 8 tähemärki',
    'remeberme' => 'Mäleta mind',
    'remember_me' => 'Mäleta mind',
    'resetpassword' => 'Taasta salasõna',
    'reset_password' => 'Taasta kasutaja salasõna ',
    'sendlink' => 'Saada salasõna taastamiseks email',
    'sign_in' => 'Logi sisse',
    'throttle' => 'Liiga mitu ebaõnnestunud sisselogimist. Proovige uuesti :seconds sekundi pärast',
    'totp_failed' => 'TOTP token oli väär. Veenduge et sisestatud token teie seadme jaoks on õige',
];
