<?php

return [
    'next' => 'Următorul &raquo;',
    'previous' => '&laquo; Anterior',
    'sidebar' => [
        'account_controls' => 'Control Cont',
        'account_security' => 'Securitate Cont',
        'account_settings' => 'Setări Cont',
        'files' => 'Manager de Fișiere',
        'manage' => 'Gestionează Server',
        'overview' => 'Afișare Server',
        'servers' => 'Serverele Tale',
        'server_controls' => 'Controlează Server',
        'subusers' => 'Gestionează Sub-Useri',
    ],
];
