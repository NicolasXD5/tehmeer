<?php

return [
    'next' => 'Prossima &raquo;',
    'previous' => '&laquo; Indietro',
    'sidebar' => [
        'account_controls' => 'Controlli Account',
        'account_security' => 'Sicurezza Account',
        'overview' => 'Panoramica Server',
        'servers' => 'Servers',
        'subusers' => 'Controlla Sub-Utenti',
    ],
];
